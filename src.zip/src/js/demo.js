const demo = () => 'Webpack Boilerplate v5.10.0 - SASS/PostCSS, ES6/7, browser sync, source code listing and more.';

// eslint-disable-next-line no-console
console.log(demo());
